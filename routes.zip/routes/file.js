var express = require('express');
var router = express.Router();
var axios = require('axios');
var multer = require('multer');

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.json({
    msg: 'respond with a resource'
  });
});

// Express route for file upload
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    // Check if a file is present
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const apiUrl = 'http://ec2-15-207-95-73.ap-south-1.compute.amazonaws.com:8080/v1/doc/upload';

    const apiResponse = await axios.post(apiUrl, req.file.buffer);

    const responseData = apiResponse.data;
    
    // Response to the client
    res.json(responseData);
  } catch (error) {
    console.error('Error uploading file:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
