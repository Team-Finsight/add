var express = require("express");
var router = express.Router();
var User = require("../model/user.js");
const { hashPassword, verifyPassword } = require("../bcryptUtils.js");
const jwt = require("jsonwebtoken");

/* GET users listing. */
router.get("/", function (req, res, next) {
  res.send("respond with a resource");
});

//Check user details for login
router.post("/", async function (req, res, body) {
  console.log("login", req.body);

  try {
    const { email, password } = req.body;

    const JWT_SECRET =
      "8Zz5tw0Ionm3XPZZfN0NOml3z9FMfmpgXwovR9fp6ryDIoGRM8EPHAB6iHsc0fb";
    // console.log('eeeee', email);

    const user = await User.findOne({ email });

    if (!user) {
      res.status(404).send("User not found");
      return;
    }

    const isPasswordValid = await verifyPassword(
      password,
      user.hashedPassword,
      user.salt
    );

    if (isPasswordValid) {
      // Check expiration time
      const currentTime = new Date();
      if (user.expirationTime && user.expirationTime < currentTime) {
        res.status(403).json({user, message:"Account has expired"});
        return;
      }
      const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: "1h" });
     // console.log("........token", token);
      res.status(200).json({ token, user, message: "Login successful" });
    } else {
      res.status(401).send("Invalid password");
    }
  } catch (error) {
    console.error("Error during login:", error.message); // Log the specific error message
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
