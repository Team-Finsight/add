var express = require("express");
var router = express.Router();
// This is your test secret API key.
const stripe = require("stripe")(
  "sk_test_51OJvMXSFRwBIUJA16LZqSlS5Gn6tMGgNRNkFY9DyhRFU3Af5jIkCEjXkbSaHeW7e6HYx1GIdeeO13RlexZq2tdzs00hAJtVcMz"
);

const calculateOrderAmount = (selectedPlan) => {
    let totalAmount = 0;

    switch (selectedPlan) {
        case "basic":
          return 149;
        case "pro":
          return 999;
        case "advanced":
          return 3499;
        default:
          return 0;
      }
    
};

router.post("/create-payment-intent", async (req, res) => {
  const { selectedPlan, user } = req.body;

  // Create a PaymentIntent with the order amount and currency
  const paymentIntent = await stripe.paymentIntents.create({
    amount: calculateOrderAmount(selectedPlan),
    currency: "inr",
    // In the latest version of the API, specifying the `automatic_payment_methods` parameter is optional because Stripe enables its functionality by default.
    automatic_payment_methods: {
      enabled: true,
    },
  });

  res.send({
    clientSecret: paymentIntent.client_secret,
    user:user
  });
});

module.exports = router;
